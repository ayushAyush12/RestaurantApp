package com.restaurantReviewApp.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.restaurantReviewApp.utils.ApiError;

@ControllerAdvice
public class GlobalExceptionHandle {
	
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<ApiError> handleResourceNotFound(ResourceNotFoundException resourceNotFoundException) {
		
		ApiError apiError=new ApiError(resourceNotFoundException.getMassage(),HttpStatus.NOT_FOUND);
		return new ResponseEntity<ApiError>(apiError,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<ApiError> handleResourceNotFound(RuntimeException runtimeException,WebRequest request) {
		
		ApiError apiError=new ApiError(runtimeException.getLocalizedMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		return new ResponseEntity<ApiError>(apiError,HttpStatus.NOT_FOUND);
	}
	


}
