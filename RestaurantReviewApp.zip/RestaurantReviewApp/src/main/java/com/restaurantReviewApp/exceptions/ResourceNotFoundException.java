package com.restaurantReviewApp.exceptions;

public class ResourceNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String massage;
	
	public ResourceNotFoundException(String massage) {
		super();
		this.massage = massage;
	}

	public String getMassage() {
		return massage;
	}
	
	
	
	
	
	

}
