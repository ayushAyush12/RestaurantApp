package com.restaurantReviewApp.service;

import java.util.List;

public interface AnalyticsService {


	Double calculateAverageRating(Long id);

	List<Object[]> findTopRestaurantsByCuisine(String cuisineType);

	
}
