package com.restaurantReviewApp.service;

import java.util.List;

import com.restaurantReviewApp.Dtos.ReviewDto;

public interface ReviewService {

	ReviewDto submitReview(long restaurnatId, ReviewDto reviewDto);

	List<ReviewDto> getReviewsByRestaurantId(Long restaurantId);

	ReviewDto updateReviewStatus(Long id, ReviewDto reviewDto);

}
