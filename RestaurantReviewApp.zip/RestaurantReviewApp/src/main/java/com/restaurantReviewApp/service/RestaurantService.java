package com.restaurantReviewApp.service;

import com.restaurantReviewApp.Dtos.RestaurantDto;
import com.restaurantReviewApp.utils.RestaurantResponse;

public interface RestaurantService {
	
	RestaurantDto createRestaurant(RestaurantDto restaurantDto);
	
	RestaurantResponse getAllRestaurants(int pageNumber, int pageSize,String sortBy);
	
	RestaurantDto getRestaurant(long id);
	

}
