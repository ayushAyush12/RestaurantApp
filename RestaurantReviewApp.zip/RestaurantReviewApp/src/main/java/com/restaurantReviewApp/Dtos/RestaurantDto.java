package com.restaurantReviewApp.Dtos;

import com.restaurantReviewApp.entity.enam.PriceRange;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RestaurantDto {
	
	private Long id;
	
	@NotEmpty(message = "Name is mandatory")
	private String name;
	@NotEmpty(message = "Cuisinetype is mandatory")
	private String cuisineType;
	@NotEmpty(message = "address is mandatory")
	private String address;
	

    private PriceRange priceRange;
	

}
