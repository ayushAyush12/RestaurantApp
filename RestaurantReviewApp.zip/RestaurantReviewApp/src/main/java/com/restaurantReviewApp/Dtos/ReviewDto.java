package com.restaurantReviewApp.Dtos;

import java.time.LocalDate;

import com.restaurantReviewApp.entity.Restaurant;
import com.restaurantReviewApp.entity.enam.ReviewStatus;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data
public class ReviewDto {
	
	private Long id;;
	@NotBlank(message = "rating is mandatory")
	@Min(value = 1, message = "Value must be at least 1")
    @Max(value = 5, message = "Value must be at most 5")
	private int rating;
	private String comment;
	private LocalDate visitDate;
	private ReviewStatus status;
	private Restaurant restaurant;

}
