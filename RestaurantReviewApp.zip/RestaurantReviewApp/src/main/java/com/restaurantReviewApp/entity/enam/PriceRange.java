package com.restaurantReviewApp.entity.enam;

public enum PriceRange {
	
	LOW,MEDIUM,HIGH

}
