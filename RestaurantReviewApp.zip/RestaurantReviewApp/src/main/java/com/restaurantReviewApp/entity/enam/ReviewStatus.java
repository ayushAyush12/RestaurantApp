package com.restaurantReviewApp.entity.enam;

public enum ReviewStatus {
	  PENDING, APPROVED

}
