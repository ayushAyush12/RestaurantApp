package com.restaurantReviewApp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.restaurantReviewApp.entity.Review;

public interface ReviewRepository extends JpaRepository<Review, Long> {
	
	List<Review> findByRestaurantId(Long restaurantId);

	@Query("SELECT AVG(r.rating) FROM Review r WHERE r.restaurant.id = :restaurantId AND r.status = 'APPROVED'")
	Double findAverageRatingByRestaurantId(@Param("restaurantId") Long restaurantId);

	@Query("SELECT r.restaurant, AVG(r.rating) as avgRating FROM Review r WHERE r.restaurant.cuisineType = :cuisineType AND r.status = 'APPROVED' GROUP BY r.restaurant ORDER BY avgRating DESC LIMIT 3")
	List<Object[]> findTopRestaurantsByCuisineType(@Param("cuisineType") String cuisineType);

}
