package com.restaurantReviewApp.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.restaurantReviewApp.Dtos.RestaurantDto;
import com.restaurantReviewApp.service.RestaurantService;
import com.restaurantReviewApp.utils.AppContent;
import com.restaurantReviewApp.utils.RestaurantResponse;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/Api/restaurant")
@RequiredArgsConstructor
public class RestaurantController {
	
	 private final RestaurantService restaurantService;
	 
	 @PostMapping("/add")
	 public ResponseEntity<RestaurantDto> createRestaurant(@Valid @RequestBody RestaurantDto restaurantDto){
		 RestaurantDto restaurant = restaurantService.createRestaurant(restaurantDto);
		 return new ResponseEntity<RestaurantDto>(restaurant,HttpStatus.CREATED);
	 }
	 @GetMapping("/{id}")
	 public ResponseEntity<RestaurantDto> getRestaurant(@PathVariable Long id){
		 RestaurantDto restaurant = restaurantService.getRestaurant(id);
		 return new ResponseEntity<RestaurantDto>(restaurant,HttpStatus.OK);
	 }
	 
	 @GetMapping("/allRestaurant")
	 public ResponseEntity<RestaurantResponse> getAllRestaurants(
			  @RequestParam(defaultValue = AppContent.DEFAULT_PAGE_NUMBER,required = false) int pageNumber,
			    @RequestParam(defaultValue = AppContent.DEFAULT_PAGE_SIZE,required = false) int pageSize,
			    @RequestParam(defaultValue = AppContent.DEFAULT_SORTBY,required = false) String sortBy){
		 
		
		 
		 RestaurantResponse allRestaurants = restaurantService.getAllRestaurants(pageNumber,pageSize,sortBy);
		 return new ResponseEntity<RestaurantResponse>(allRestaurants,HttpStatus.OK);
	 }
	
	
	

}
