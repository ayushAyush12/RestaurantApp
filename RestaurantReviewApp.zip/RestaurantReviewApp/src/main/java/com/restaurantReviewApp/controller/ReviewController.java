package com.restaurantReviewApp.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.restaurantReviewApp.Dtos.ReviewDto;
import com.restaurantReviewApp.service.ReviewService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/Api/review")
public class ReviewController {
	
	
    private final ReviewService reviewService;

    @PostMapping("/{restaurantId}")
    public ResponseEntity<ReviewDto> submitReview(@PathVariable Long restaurantId,@Valid @RequestBody ReviewDto reviewDto) {
      ReviewDto submitReview = reviewService.submitReview(restaurantId,  reviewDto);
      return new ResponseEntity<ReviewDto>(submitReview,HttpStatus.CREATED);
    }

    @GetMapping("/{restaurantId}")
    public ResponseEntity<List<ReviewDto>> getReviewsByRestaurantId(@PathVariable Long restaurantId) {
    	List<ReviewDto> reviewsByRestaurantId = reviewService.getReviewsByRestaurantId(restaurantId);
       return new ResponseEntity<List<ReviewDto>>(reviewsByRestaurantId,HttpStatus.OK);
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<ReviewDto> updateReviewStatus(@PathVariable Long id, @RequestParam ReviewDto reviewDto) {
      
		ReviewDto updateReviewStatus = reviewService.updateReviewStatus(id, reviewDto);
		 return new ResponseEntity<ReviewDto>(updateReviewStatus,HttpStatus.OK);
    }

}
