package com.restaurantReviewApp.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.restaurantReviewApp.service.AnalyticsService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/analytics")
public class AnalyticsController {

	private final AnalyticsService analyticsService;

	@GetMapping("/restaurants/{id}/average-rating")
	public Double getAverageRating(@PathVariable Long id) {
		return analyticsService.calculateAverageRating(id);
	}

	@GetMapping("/restaurants/topCuisineBased")
	public ResponseEntity<List<Object[]>> findTopRestaurantsByCuisine(@RequestParam String cuisineType) {

		List<Object[]> topRestaurantsByCuisine = analyticsService.findTopRestaurantsByCuisine(cuisineType);
		return new ResponseEntity<List<Object[]>>(topRestaurantsByCuisine,HttpStatus.OK);
	}

}
