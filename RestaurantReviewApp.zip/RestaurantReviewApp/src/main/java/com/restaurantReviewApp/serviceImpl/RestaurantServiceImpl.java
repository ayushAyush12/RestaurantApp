package com.restaurantReviewApp.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;

import com.restaurantReviewApp.Dtos.RestaurantDto;
import com.restaurantReviewApp.entity.Restaurant;
import com.restaurantReviewApp.entity.enam.PriceRange;
import com.restaurantReviewApp.repository.RestaurantRepository;
import com.restaurantReviewApp.service.RestaurantService;
import com.restaurantReviewApp.utils.RestaurantResponse;

import lombok.RequiredArgsConstructor;
@Service
@RequiredArgsConstructor
public class RestaurantServiceImpl  implements RestaurantService{
	
	private final RestaurantRepository restaurantRepository;
	private final ModelMapper modelMapper;

	@Override
	public RestaurantDto createRestaurant(RestaurantDto restaurantDto) {
		// Restaurant restaurant = modelMapper.map(restaurantDto, Restaurant.class);
		Restaurant restaurant=new Restaurant();
		restaurant.setAddress(restaurantDto.getAddress());
		restaurant.setCuisineType(restaurantDto.getCuisineType());
		restaurant.setName(restaurantDto.getName());
		 restaurant.setPriceRange(PriceRange.LOW);
		 Restaurant savedRestaurant = restaurantRepository.save(restaurant);
		
		return  modelMapper.map(savedRestaurant, RestaurantDto.class);
	}

	@Override
	public RestaurantResponse getAllRestaurants(int pageNumber, int pageSize,String sortBy) {
		
		PageRequest pageable=PageRequest.of(pageNumber, pageSize, Sort.by(sortBy));
		Page<Restaurant> page = restaurantRepository.findAll(pageable);
		List<Restaurant> list = page.toList();
		List<RestaurantDto> list2 = list.stream().map(restaurant->modelMapper.map(restaurant, RestaurantDto.class)).collect(Collectors.toList());
		
		RestaurantResponse restaurantResponse = RestaurantResponse.builder()
		.content(list2)
		.pageNumber(page.getNumber())
		.pageSize(page.getSize())
		.totalElements(page.getTotalElements())
		.totalPages(page.getTotalPages())
		.build();
		return restaurantResponse;
	}

	@Override
	public RestaurantDto getRestaurant(long id) {
	     Restaurant restaurant = restaurantRepository
	    		 .findById(id).orElseThrow(()->new ResourceAccessException("restaurant not found exception"));
	     return modelMapper.map(restaurant, RestaurantDto.class);
	}

}
