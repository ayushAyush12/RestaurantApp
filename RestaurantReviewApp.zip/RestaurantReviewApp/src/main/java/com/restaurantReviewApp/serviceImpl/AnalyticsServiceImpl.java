package com.restaurantReviewApp.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.restaurantReviewApp.repository.ReviewRepository;
import com.restaurantReviewApp.service.AnalyticsService;

import lombok.RequiredArgsConstructor;
@Service
@RequiredArgsConstructor
public class AnalyticsServiceImpl implements AnalyticsService {
	
	private final ReviewRepository reviewRepository;

	@Override
	public Double calculateAverageRating(Long id) {
		Double averageRatingByRestaurantId = reviewRepository.findAverageRatingByRestaurantId(id);
		return averageRatingByRestaurantId;
	}

	@Override
	public List<Object[]> findTopRestaurantsByCuisine(String cuisineType) {
		 List<Object[]> topRestaurantsByCuisineType = reviewRepository.findTopRestaurantsByCuisineType(cuisineType);
		return topRestaurantsByCuisineType;
		
	}
	
	
	

}
