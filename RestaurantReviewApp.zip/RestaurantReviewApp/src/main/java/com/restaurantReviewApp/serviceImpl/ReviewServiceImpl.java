package com.restaurantReviewApp.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.restaurantReviewApp.Dtos.ReviewDto;
import com.restaurantReviewApp.entity.Restaurant;
import com.restaurantReviewApp.entity.Review;
import com.restaurantReviewApp.exceptions.ResourceNotFoundException;
import com.restaurantReviewApp.repository.RestaurantRepository;
import com.restaurantReviewApp.repository.ReviewRepository;
import com.restaurantReviewApp.service.ReviewService;

import lombok.RequiredArgsConstructor;
@Service
@RequiredArgsConstructor
public class ReviewServiceImpl implements ReviewService {

	private final ReviewRepository reviewRepository;
	private final RestaurantRepository restaurantRepository;
	private ModelMapper modelMapper;
	
	@Override
	public ReviewDto submitReview(long restaurnatId, ReviewDto reviewDto) {
		Review review = modelMapper.map(reviewDto,Review.class);
		Restaurant restaurant = restaurantRepository.findById(restaurnatId).orElseThrow(()->new ResourceNotFoundException("restaurant not found"));
		review.setRestaurant(restaurant);
		Review savedReview = reviewRepository.save(review);
		return modelMapper.map(savedReview, ReviewDto.class);
	}

	@Override
	public List<ReviewDto> getReviewsByRestaurantId(Long restaurantId) {
		List<Review> restaurantReview = reviewRepository.findByRestaurantId(restaurantId);
		List<ReviewDto> collect = restaurantReview
				.stream()
				.map(review->modelMapper.map(review, ReviewDto.class))
				.collect(Collectors.toList());
		
		return collect;
	}

	@Override
	public ReviewDto updateReviewStatus(Long id, ReviewDto reviewDto) {
		Review review = modelMapper.map(reviewDto, Review.class);
		Review savedReview = reviewRepository.save(review);
		return modelMapper.map(savedReview, ReviewDto.class);
	}

}
