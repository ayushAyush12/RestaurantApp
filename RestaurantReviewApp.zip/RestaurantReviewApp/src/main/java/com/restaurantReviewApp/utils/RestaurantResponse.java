package com.restaurantReviewApp.utils;

import java.util.List;

import com.restaurantReviewApp.Dtos.RestaurantDto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RestaurantResponse {
	
	private List<RestaurantDto> content;
	private int pageNumber;
	private int pageSize;
	private long totalElements;
	private int totalPages;
	private boolean last;
	
	
	

}
